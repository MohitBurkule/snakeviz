from .ipymagic import *

VERSION = version = __version__ = '2.3.dev.0'
